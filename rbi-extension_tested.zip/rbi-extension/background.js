// background.js — RBI Enforcer service worker
//
// Header injected: x-rbi-policy: true
// Mechanism: declarativeNetRequest (MV3 standard, identical on Brave/Edge/Chrome).
//
// Two modes of operation:
//   1. Global enforcement (master switch ON) -> one session rule tags ALL main-frame
//      navigations with the header.
//   2. Per-tab "open in RBI" -> a dynamic rule scoped to a specific tabId, so a single
//      site can be isolated without flipping the global switch.

const HEADER_NAME = "x-rbi-policy";
const HEADER_VALUE = "true";

const GLOBAL_RULE_ID = 1;          // reserved id for the global rule
const PERTAB_RULE_BASE = 1000;     // per-tab rules live at >= 1000

const STORAGE_KEY = "rbiEnabled";

// --- Helpers ---------------------------------------------------------------

function headerAction() {
  return {
    type: "modifyHeaders",
    requestHeaders: [
      { header: HEADER_NAME, operation: "set", value: HEADER_VALUE }
    ]
  };
}

async function setGlobalRule(enabled) {
  const removeRuleIds = [GLOBAL_RULE_ID];
  const addRules = enabled
    ? [{
        id: GLOBAL_RULE_ID,
        priority: 1,
        action: headerAction(),
        condition: {
          urlFilter: "*",
          resourceTypes: ["main_frame", "sub_frame"]
        }
      }]
    : [];

  await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds, addRules });
  await updateBadge(enabled);
}

async function updateBadge(enabled) {
  await chrome.action.setBadgeText({ text: enabled ? "ON" : "" });
  await chrome.action.setBadgeBackgroundColor({ color: "#1f6f54" });
}

async function getEnabled() {
  const { [STORAGE_KEY]: v } = await chrome.storage.local.get(STORAGE_KEY);
  return v === true;
}

async function addPerTabRule(tabId) {
  // Tag every main-frame request from this specific tab.
  const ruleId = PERTAB_RULE_BASE + (tabId % 100000);
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [ruleId],
    addRules: [{
      id: ruleId,
      priority: 2,
      action: headerAction(),
      condition: {
        tabIds: [tabId],
        resourceTypes: ["main_frame", "sub_frame"]
      }
    }]
  });
}

async function clearPerTabRule(tabId) {
  const ruleId = PERTAB_RULE_BASE + (tabId % 100000);
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: [ruleId] });
}

// --- Lifecycle -------------------------------------------------------------

chrome.runtime.onInstalled.addListener(async () => {
  const enabled = await getEnabled();
  await setGlobalRule(enabled);
  buildContextMenus();
});

chrome.runtime.onStartup.addListener(async () => {
  const enabled = await getEnabled();
  await setGlobalRule(enabled);
  buildContextMenus();
});

// --- Context menus ---------------------------------------------------------

function buildContextMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "open-link-rbi",
      title: "Open link in RBI",
      contexts: ["link"]
    });
    chrome.contextMenus.create({
      id: "open-page-rbi",
      title: "Open this page in RBI (new tab)",
      contexts: ["page"]
    });
    chrome.contextMenus.create({
      id: "toggle-all-rbi",
      title: "Isolate all sites (global RBI)",
      contexts: ["action"]
    });
  });
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "open-link-rbi" && info.linkUrl) {
    await openInRbi(info.linkUrl);
  } else if (info.menuItemId === "open-page-rbi") {
    const url = info.pageUrl || (tab && tab.url);
    if (url) await openInRbi(url);
  } else if (info.menuItemId === "toggle-all-rbi") {
    const next = !(await getEnabled());
    await chrome.storage.local.set({ [STORAGE_KEY]: next });
    await setGlobalRule(next);
  }
});

async function openInRbi(url) {
  // Create the tab first, register a per-tab rule, then navigate so the very
  // first request carries the header.
  const tab = await chrome.tabs.create({ url: "about:blank" });
  await addPerTabRule(tab.id);
  await chrome.tabs.update(tab.id, { url });
}

// Clean up per-tab rules when tabs close.
chrome.tabs.onRemoved.addListener((tabId) => {
  clearPerTabRule(tabId);
});

// --- Messages from popup ---------------------------------------------------

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    if (msg.type === "getState") {
      sendResponse({ enabled: await getEnabled() });
    } else if (msg.type === "setState") {
      await chrome.storage.local.set({ [STORAGE_KEY]: msg.enabled });
      await setGlobalRule(msg.enabled);
      sendResponse({ enabled: msg.enabled });
    } else if (msg.type === "openCurrentInRbi") {
      const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (active && active.url) await openInRbi(active.url);
      sendResponse({ ok: true });
    }
  })();
  return true; // async response
});
