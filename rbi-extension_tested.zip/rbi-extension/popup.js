// popup.js
const toggle = document.getElementById("toggle");
const stateText = document.getElementById("stateText");
const openCurrent = document.getElementById("openCurrent");

function render(enabled) {
  toggle.setAttribute("aria-pressed", String(enabled));
  stateText.textContent = enabled ? "On" : "Off";
  stateText.classList.toggle("on", enabled);
}

chrome.runtime.sendMessage({ type: "getState" }, (res) => {
  render(res && res.enabled);
});

toggle.addEventListener("click", () => {
  const next = toggle.getAttribute("aria-pressed") !== "true";
  chrome.runtime.sendMessage({ type: "setState", enabled: next }, (res) => {
    render(res && res.enabled);
  });
});

openCurrent.addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "openCurrentInRbi" }, () => window.close());
});
